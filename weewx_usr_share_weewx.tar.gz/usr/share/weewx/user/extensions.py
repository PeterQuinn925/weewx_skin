#
#
#    See the file LICENSE.txt for your full rights.
#

"""User extensions module

This module is imported from the main executable, so anything put here will be
executed before anything else happens. This makes it a good place to put user
extensions.
"""

import locale
# This will use the locale specified by the environment variable 'LANG'
# Other options are possible. See:
# http://docs.python.org/2/library/locale.html#locale.setlocale
locale.setlocale(locale.LC_ALL, '')

import syslog
import weewx
from weewx.wxengine import StdService

class extraTService(StdService):
    def __init__(self, engine, config_dict):
        super(extraTService, self).__init__(engine, config_dict)
        d = config_dict.get('extraTService', {})
        self.filename = d.get('filename', '/var/temp/extra_temp.txt')
        syslog.syslog(syslog.LOG_INFO, "extratemp: using %s" % self.filename)
        self.bind(weewx.NEW_ARCHIVE_RECORD, self.read_file)

    def read_file(self, event):
        try:
            with open(self.filename) as f:
                value = f.read()
            syslog.syslog(syslog.LOG_DEBUG, "extratemp: found value of %s" % value)
            event.record['extraTemp1'] = float(value)
        except Exception, e:
            syslog.syslog(syslog.LOG_ERR, "extratemp: cannot read value: %s" % e)

